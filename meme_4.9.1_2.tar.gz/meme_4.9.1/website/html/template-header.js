/*
 * $Id$
 *
 * $Log$
 * Revision 1.2  2006/03/07 23:30:20  nadya
 * merge branches v3_5_1 and v3_5_2 back to the trunk
 *
 * Revision 1.1.2.1  2006/02/22 20:47:48  nadya
 * initial revision. enabling styling with js and css
 *
 */

document.write("<table class=maintable>");
document.write("<tr>");
document.write("<td class=menubase>");
document.write("<div id=menu>");

document.write("<script src='../meme-suite-menu.js' type='text/javascript'></script>");
document.write("<script type='text/javascript'>make_menu();</script>");

document.write("</div>");
document.write("</td>");
document.write("<td class=maintablewidth>");
document.write("<div id=main>");
