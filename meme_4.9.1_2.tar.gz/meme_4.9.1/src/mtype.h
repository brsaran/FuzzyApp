/*
 * $Id: mtype.h 1048 2006-07-06 20:07:44Z cegrant $
 * 
 * $Log$
 * Revision 1.1  2005/07/29 18:45:54  nadya
 * Initial revision
 *
 */

#ifndef mtype_h
# define mtype_h

/* types of models */
typedef enum {Tcm, Oops, Zoops} MOTYPE;

#endif /* mtype_h */
